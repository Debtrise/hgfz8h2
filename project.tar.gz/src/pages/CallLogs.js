// src/pages/CallLogs.js
import React, { useState, useEffect } from 'react';
import {
  Card,
  Table,
  Input,
  Select,
  DatePicker,
  Space,
  Button,
  Tag,
  Tooltip,
  Modal,
  Typography,
  Row,
  Col,
  Statistic,
  Timeline,
} from 'antd';
import {
  SearchOutlined,
  PhoneOutlined,
  ClockCircleOutlined,
  UserOutlined,
  AudioOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  InfoCircleOutlined,
} from '@ant-design/icons';
import moment from 'moment';
import AuthService from '../services/AuthService';

const { RangePicker } = DatePicker;
const { Option } = Select;
const { Title, Text } = Typography;

const CallLogs = () => {
  const [loading, setLoading] = useState(false);
  const [callLogs, setCallLogs] = useState([]);
  const [filters, setFilters] = useState({
    dateRange: [moment().startOf('day'), moment().endOf('day')],
    status: 'all',
    direction: 'all',
    agent: 'all',
    search: '',
  });
  const [selectedCall, setSelectedCall] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [statistics, setStatistics] = useState({
    totalCalls: 0,
    avgDuration: 0,
    successRate: 0,
    totalInbound: 0,
    totalOutbound: 0,
  });

  // Simulated data - in a real app, this would come from an API
  useEffect(() => {
    fetchCallLogs();
  }, [filters]);

  const fetchCallLogs = async () => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Generate mock data
      const mockData = Array.from({ length: 50 }, (_, index) => ({
        id: index + 1,
        timestamp: moment().subtract(Math.random() * 24, 'hours').format('YYYY-MM-DD HH:mm:ss'),
        phoneNumber: `+1${Math.floor(Math.random() * 9000000000 + 1000000000)}`,
        direction: Math.random() > 0.5 ? 'Inbound' : 'Outbound',
        agent: ['John Doe', 'Jane Smith', 'Mike Johnson'][Math.floor(Math.random() * 3)],
        duration: Math.floor(Math.random() * 600),
        status: ['Completed', 'No Answer', 'Busy', 'Failed'][Math.floor(Math.random() * 4)],
        disposition: ['Sale', 'Follow Up', 'Not Interested', 'Wrong Number'][Math.floor(Math.random() * 4)],
        recording: Math.random() > 0.3,
        notes: 'Customer inquired about new service options.',
        queue: ['Sales', 'Support', 'Billing'][Math.floor(Math.random() * 3)],
      }));

      setCallLogs(mockData);
      
      // Calculate statistics
      const totalCalls = mockData.length;
      const avgDuration = Math.floor(mockData.reduce((acc, call) => acc + call.duration, 0) / totalCalls);
      const successfulCalls = mockData.filter(call => call.status === 'Completed').length;
      const inboundCalls = mockData.filter(call => call.direction === 'Inbound').length;
      
      setStatistics({
        totalCalls,
        avgDuration,
        successRate: Math.floor((successfulCalls / totalCalls) * 100),
        totalInbound: inboundCalls,
        totalOutbound: totalCalls - inboundCalls,
      });

    } catch (error) {
      console.error('Error fetching call logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (value, type) => {
    setFilters(prev => ({ ...prev, [type]: value }));
  };

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const columns = [
    {
      title: 'Timestamp',
      dataIndex: 'timestamp',
      sorter: (a, b) => moment(a.timestamp).unix() - moment(b.timestamp).unix(),
      render: (text) => moment(text).format('MM/DD/YYYY HH:mm:ss'),
    },
    {
      title: 'Direction',
      dataIndex: 'direction',
      render: (text) => (
        <Tag color={text === 'Inbound' ? 'green' : 'blue'}>
          {text}
        </Tag>
      ),
    },
    {
      title: 'Phone Number',
      dataIndex: 'phoneNumber',
      render: (text) => (
        <Space>
          <PhoneOutlined />
          {text}
        </Space>
      ),
    },
    {
      title: 'Agent',
      dataIndex: 'agent',
      render: (text) => (
        <Space>
          <UserOutlined />
          {text}
        </Space>
      ),
    },
    {
      title: 'Duration',
      dataIndex: 'duration',
      sorter: (a, b) => a.duration - b.duration,
      render: (text) => (
        <Space>
          <ClockCircleOutlined />
          {formatDuration(text)}
        </Space>
      ),
    },
    {
      title: 'Status',
      dataIndex: 'status',
      render: (text) => {
        const color = text === 'Completed' ? 'success' : text === 'Failed' ? 'error' : 'warning';
        return <Tag color={color}>{text}</Tag>;
      },
    },
    {
      title: 'Recording',
      dataIndex: 'recording',
      render: (hasRecording) => (
        hasRecording ? (
          <Tooltip title="Play Recording">
            <Button type="link" icon={<AudioOutlined />} />
          </Tooltip>
        ) : (
          <Text type="secondary">No recording</Text>
        )
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Button
          type="link"
          icon={<InfoCircleOutlined />}
          onClick={() => {
            setSelectedCall(record);
            setModalVisible(true);
          }}
        >
          Details
        </Button>
      ),
    },
  ];

  const renderCallDetails = () => {
    if (!selectedCall) return null;

    return (
      <Modal
        title="Call Details"
        visible={modalVisible}
        onCancel={() => setModalVisible(false)}
        footer={null}
        width={700}
      >
        <Row gutter={[16, 16]}>
          <Col span={12}>
            <Card size="small" title="Basic Information">
              <p><strong>Phone Number:</strong> {selectedCall.phoneNumber}</p>
              <p><strong>Direction:</strong> {selectedCall.direction}</p>
              <p><strong>Agent:</strong> {selectedCall.agent}</p>
              <p><strong>Queue:</strong> {selectedCall.queue}</p>
              <p><strong>Duration:</strong> {formatDuration(selectedCall.duration)}</p>
            </Card>
          </Col>
          <Col span={12}>
            <Card size="small" title="Call Outcome">
              <p><strong>Status:</strong> {selectedCall.status}</p>
              <p><strong>Disposition:</strong> {selectedCall.disposition}</p>
              <p><strong>Recording:</strong> {selectedCall.recording ? 'Available' : 'Not available'}</p>
            </Card>
          </Col>
          <Col span={24}>
            <Card size="small" title="Notes">
              <p>{selectedCall.notes}</p>
            </Card>
          </Col>
        </Row>
      </Modal>
    );
  };

  return (
    <div className="call-logs-page">
      {/* Statistics Cards */}
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        <Col span={4}>
          <Card>
            <Statistic
              title="Total Calls"
              value={statistics.totalCalls}
              prefix={<PhoneOutlined />}
            />
          </Card>
        </Col>
        <Col span={4}>
          <Card>
            <Statistic
              title="Avg Duration"
              value={formatDuration(statistics.avgDuration)}
              prefix={<ClockCircleOutlined />}
            />
          </Card>
        </Col>
        <Col span={4}>
          <Card>
            <Statistic
              title="Success Rate"
              value={statistics.successRate}
              suffix="%"
              prefix={<CheckCircleOutlined />}
            />
          </Card>
        </Col>
        <Col span={4}>
          <Card>
            <Statistic
              title="Inbound Calls"
              value={statistics.totalInbound}
              valueStyle={{ color: '#3f8600' }}
            />
          </Card>
        </Col>
        <Col span={4}>
          <Card>
            <Statistic
              title="Outbound Calls"
              value={statistics.totalOutbound}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
      </Row>

      {/* Filters */}
      <Card style={{ marginBottom: 16 }}>
        <Space style={{ marginBottom: 16 }}>
          <RangePicker
            showTime
            value={filters.dateRange}
            onChange={(dates) => handleFilterChange(dates, 'dateRange')}
          />
          <Select
            style={{ width: 120 }}
            value={filters.status}
            onChange={(value) => handleFilterChange(value, 'status')}
          >
            <Option value="all">All Status</Option>
            <Option value="completed">Completed</Option>
            <Option value="failed">Failed</Option>
            <Option value="no_answer">No Answer</Option>
          </Select>
          <Select
            style={{ width: 120 }}
            value={filters.direction}
            onChange={(value) => handleFilterChange(value, 'direction')}
          >
            <Option value="all">All Directions</Option>
            <Option value="inbound">Inbound</Option>
            <Option value="outbound">Outbound</Option>
          </Select>
          <Input
            placeholder="Search phone number or agent"
            prefix={<SearchOutlined />}
            style={{ width: 200 }}
            value={filters.search}
            onChange={(e) => handleFilterChange(e.target.value, 'search')}
          />
          <Button type="primary" onClick={fetchCallLogs}>
            Refresh
          </Button>
        </Space>
      </Card>

      {/* Call Logs Table */}
      <Card>
        <Table
          columns={columns}
          dataSource={callLogs}
          loading={loading}
          rowKey="id"
          pagination={{
            total: callLogs.length,
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
          }}
        />
      </Card>

      {/* Call Details Modal */}
      {renderCallDetails()}
    </div>
  );
};

export default CallLogs;

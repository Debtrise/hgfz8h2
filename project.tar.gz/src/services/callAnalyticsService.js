const BASE_URL = 'http://34.134.140.42:3010';
const AGENT_STATUS_URL = 'https://dialer-api-154842307047.us-west2.run.app/getAgentStatus';
const QUEUE_COUNTS_URL = 'https://dialer-api-154842307047.us-west2.run.app/getDialerQueueCounts';
const DIALER_CONTROL_URL = 'https://dialer-api-154842307047.us-west2.run.app/getDialerControl';
const UPDATE_DIALER_URL = 'https://dialer-api-154842307047.us-west2.run.app/updateDialerControl';
const CALL_DETECTION_URL = 'http://34.134.140.42:8080/stats';
const HOURLY_STATS_URL = 'http://34.134.140.42:3010/api/stats/hourly';

export const callAnalyticsService = {
  // Get today's summary statistics
  getTodaySummary: async () => {
    try {
      const response = await fetch(`${BASE_URL}/api/stats/today`);
      if (!response.ok) throw new Error('Failed to fetch today\'s summary');
      return await response.json();
    } catch (error) {
      console.error('Error fetching today\'s summary:', error);
      throw error;
    }
  },

  // Get hourly breakdown for a specific date
  getHourlyBreakdown: async (date) => {
    try {
      const response = await fetch(`${BASE_URL}/api/stats/hourly?date=${date}`);
      if (!response.ok) throw new Error('Failed to fetch hourly breakdown');
      return await response.json();
    } catch (error) {
      console.error('Error fetching hourly breakdown:', error);
      throw error;
    }
  },

  // Get daily statistics for a date range
  getDailyStats: async (startDate, endDate) => {
    try {
      const response = await fetch(`${BASE_URL}/api/stats/daily?startDate=${startDate}&endDate=${endDate}`);
      if (!response.ok) throw new Error('Failed to fetch daily statistics');
      return await response.json();
    } catch (error) {
      console.error('Error fetching daily statistics:', error);
      throw error;
    }
  },

  // Get real-time monitoring data
  getRealTimeStats: async () => {
    try {
      const response = await fetch(`${BASE_URL}/api/stats/real-time`);
      if (!response.ok) throw new Error('Failed to fetch real-time stats');
      return await response.json();
    } catch (error) {
      console.error('Error fetching real-time stats:', error);
      throw error;
    }
  },

  // Get agent status
  getAgentStatus: async () => {
    try {
      const response = await fetch(AGENT_STATUS_URL);
      if (!response.ok) throw new Error('Failed to fetch agent status');
      return await response.json();
    } catch (error) {
      console.error('Error fetching agent status:', error);
      throw error;
    }
  },

  // Get dialer queue counts
  getDialerQueueCounts: async () => {
    try {
      const response = await fetch(QUEUE_COUNTS_URL);
      if (!response.ok) throw new Error('Failed to fetch dialer queue counts');
      return await response.json();
    } catch (error) {
      console.error('Error fetching dialer queue counts:', error);
      throw error;
    }
  },

  // Get dialer control settings
  getDialerControl: async () => {
    try {
      const response = await fetch(DIALER_CONTROL_URL);
      if (!response.ok) throw new Error('Failed to fetch dialer control settings');
      const data = await response.json();
      return {
        speed: data.speed || 0,
        multiplier: data.multiplier || 5,
        status: data.status || 'active',
        min_agent_availability: data.min_agent_availability || 2,
        id: data.id || 1
      };
    } catch (error) {
      console.error('Error fetching dialer control settings:', error);
      throw error;
    }
  },

  // Update dialer control settings
  updateDialerControl: async (settings) => {
    try {
      const response = await fetch(UPDATE_DIALER_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          speed: settings.speed || 0,
          multiplier: 5,
          status: 'active',
          min_agent_availability: settings.minAgents || 2,
          id: 1
        })
      });
      if (!response.ok) throw new Error('Failed to update dialer control settings');
      return await response.json();
    } catch (error) {
      console.error('Error updating dialer control settings:', error);
      throw error;
    }
  },

  // Get call detection statistics
  getCallDetectionStats: async () => {
    try {
      const response = await fetch(CALL_DETECTION_URL);
      if (!response.ok) throw new Error('Failed to fetch call detection stats');
      return await response.json();
    } catch (error) {
      console.error('Error fetching call detection stats:', error);
      throw error;
    }
  },

  // Get hourly statistics
  getHourlyStats: async () => {
    try {
      const response = await fetch(HOURLY_STATS_URL);
      if (!response.ok) throw new Error('Failed to fetch hourly stats');
      return await response.json();
    } catch (error) {
      console.error('Error fetching hourly stats:', error);
      throw error;
    }
  }
}; 